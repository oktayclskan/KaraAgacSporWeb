﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesLayer
{
    internal class ConnectionStrings
    {
        //public static string ConStr = @"data source =.\SQLEXPRESS;Integrated Security = SSPI; AttachDBFilename=|DataDirectory|aspnetdb.mdf;User Instance = true";
        public static string ConStr = @"Data Source=94.199.202.242;Network Library=DBMSSOCN;Initial Catalog=hhbadakd_Karaagac;User ID=appsolypreparation;Password=493052Hhb-";
    }
    
}
