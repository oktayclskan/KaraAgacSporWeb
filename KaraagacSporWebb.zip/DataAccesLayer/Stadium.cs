﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesLayer
{
    public class Stadium
    {
        public int ID { get; set; }
        public string StadiumName { get; set; }
        public string StadiumCity { get; set; }
        public string StadiumDistrict { get; set; }
    }
}
