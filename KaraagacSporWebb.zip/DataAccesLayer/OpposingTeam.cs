﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesLayer
{
    public class OpposingTeam
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string logo { get; set; }
    }
}
